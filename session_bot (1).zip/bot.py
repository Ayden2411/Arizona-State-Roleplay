# bot.py
# Discord Session Bot

import discord
from discord.ext import commands
from discord import app_commands
import sqlite3

INTENTS = discord.Intents.default()
INTENTS.members = True

bot = commands.Bot(command_prefix="?", intents=INTENTS)

db = sqlite3.connect("sessions.db")
cursor = db.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS config (
    guild_id INTEGER PRIMARY KEY,
    allowed_role INTEGER,
    command_channel INTEGER,
    output_channel INTEGER,
    staff_channel INTEGER,
    message_text TEXT,
    image_url TEXT,
    ping TEXT,
    votes_required INTEGER
)
""")
db.commit()

def get_config(guild_id):
    cursor.execute("SELECT * FROM config WHERE guild_id = ?", (guild_id,))
    return cursor.fetchone()

def set_config(data):
    cursor.execute("INSERT OR REPLACE INTO config VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", data)
    db.commit()

class SetupModal(discord.ui.Modal, title="Session Setup"):
    def __init__(self):
        super().__init__()
        self.text = discord.ui.TextInput(label="Session Text", style=discord.TextStyle.paragraph)
        self.image = discord.ui.TextInput(label="Image URL", required=False)
        self.ping = discord.ui.TextInput(label="Ping", required=False)
        self.allowed_role = discord.ui.TextInput(label="Allowed Role ID")
        self.command_channel = discord.ui.TextInput(label="Command Channel ID")
        self.output_channel = discord.ui.TextInput(label="Output Channel ID")
        self.staff_channel = discord.ui.TextInput(label="Staff Channel ID")
        self.votes = discord.ui.TextInput(label="Votes Required")

        for i in [self.text, self.image, self.ping, self.allowed_role, self.command_channel, self.output_channel, self.staff_channel, self.votes]:
            self.add_item(i)

    async def on_submit(self, interaction: discord.Interaction):
        set_config((
            interaction.guild.id,
            int(self.allowed_role.value),
            int(self.command_channel.value),
            int(self.output_channel.value),
            int(self.staff_channel.value),
            self.text.value,
            self.image.value,
            self.ping.value,
            int(self.votes.value)
        ))
        await interaction.response.send_message("Setup complete.", ephemeral=True)

@bot.tree.command(name="setup")
async def setup(interaction: discord.Interaction):
    if interaction.user.id != interaction.guild.owner_id:
        await interaction.response.send_message("Owner only.", ephemeral=True)
        return
    await interaction.response.send_modal(SetupModal())

class SessionView(discord.ui.View):
    async def handle(self, interaction, name):
        cfg = get_config(interaction.guild.id)
        if not cfg:
            return await interaction.response.send_message("Not setup.", ephemeral=True)

        (_, role_id, cmd_ch, out_ch, _, text, image, ping, _) = cfg

        if interaction.channel.id != cmd_ch:
            return await interaction.response.send_message("Wrong channel.", ephemeral=True)

        if role_id not in [r.id for r in interaction.user.roles]:
            return await interaction.response.send_message("No permission.", ephemeral=True)

        embed = discord.Embed(title=name, description=text)
        if image:
            embed.set_image(url=image)

        channel = interaction.guild.get_channel(out_ch)
        await channel.send(content=ping or None, embed=embed)
        await interaction.response.send_message("Sent.", ephemeral=True)

    @discord.ui.button(label="SSU", style=discord.ButtonStyle.green)
    async def ssu(self, interaction, _): await self.handle(interaction, "SSU")

    @discord.ui.button(label="LOW", style=discord.ButtonStyle.secondary)
    async def low(self, interaction, _): await self.handle(interaction, "LOW")

    @discord.ui.button(label="FULL", style=discord.ButtonStyle.danger)
    async def full(self, interaction, _): await self.handle(interaction, "FULL")

    @discord.ui.button(label="SSD", style=discord.ButtonStyle.primary)
    async def ssd(self, interaction, _): await self.handle(interaction, "SSD")

@bot.tree.command(name="sessionpanel")
async def panel(interaction: discord.Interaction):
    await interaction.response.send_message("Session Panel", view=SessionView())

class VoteView(discord.ui.View):
    def __init__(self, required, author, staff_channel):
        super().__init__(timeout=None)
        self.votes = set()
        self.required = required
        self.author = author
        self.staff_channel = staff_channel

    @discord.ui.button(label="Vote SSU", style=discord.ButtonStyle.green)
    async def vote(self, interaction, _):
        self.votes.add(interaction.user.id)
        if len(self.votes) >= self.required:
            staff = interaction.guild.get_channel(self.staff_channel)
            await staff.send(f"<@{self.author.id}> SSU vote reached.")
            self.clear_items()
            await interaction.message.edit(view=self)
        else:
            await interaction.response.send_message(f"{len(self.votes)}/{self.required}", ephemeral=True)

@bot.tree.command(name="ssuvote")
async def ssuvote(interaction: discord.Interaction):
    cfg = get_config(interaction.guild.id)
    if not cfg:
        return await interaction.response.send_message("Not setup.", ephemeral=True)

    (_, _, cmd_ch, out_ch, staff_ch, _, _, _, votes) = cfg

    if interaction.channel.id != cmd_ch:
        return await interaction.response.send_message("Wrong channel.", ephemeral=True)

    embed = discord.Embed(title="SSU Vote", description=f"{votes} votes required.")
    channel = interaction.guild.get_channel(out_ch)
    await channel.send(embed=embed, view=VoteView(votes, interaction.user, staff_ch))
    await interaction.response.send_message("Vote started.", ephemeral=True)

@bot.event
async def on_ready():
    await bot.tree.sync()
    print("Bot ready")

bot.run("PUT_YOUR_TOKEN_HERE")
