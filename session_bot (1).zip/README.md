# Session Bot

## Setup
1. Install Python 3.10+
2. Run: pip install -r requirements.txt
3. Paste your bot token into bot.py
4. Run: python bot.py

## Commands
/setup - configure system
/sessionpanel - session buttons
/ssuvote - start SSU vote
